<?php
// Include database connection file
include "header.php";
include "db.php";

// Check if form is submitted
if (isset($_POST["submit"])) {
    // Get form data
    $id = $_POST["id"];
    $name = $_POST["full_name"];
    $blood_group = $_POST["blood_type"];
    $phone = $_POST["phone"];
    $location = $_POST["address"];
    $last_donation = $_POST["last_donation"];
    $Organization = $_POST["Organization"];
   

    // Update donor's information
    $sql = "UPDATE blood_donors SET full_name='$name', blood_type='$blood_group', phone='$phone', address='$location', last_donation='$last_donation' , Organization ='$Organization' WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        // Redirect to index.php
       include "view.php";
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Get donor's information
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "SELECT * FROM blood_donors WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $name = $row["full_name"];
        $blood_group = $row["blood_type"];
        $phone = $row["phone"];
        $location = $row["address"];
        $last_donation = $row["last_donation"];
    } else {
        echo "No donor found";
        exit();
    }
} else {
    echo "Invalid request";
    exit();
}
?>

<!-- HTML code for edit form -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Donor Information</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Edit Donor Information</h2>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="full_name" value="<?php echo $name; ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Blood Group</label>
                <select name="blood_type" class="form-control" required>
                    <option value="" <?php if ($blood_group == "")
                        echo "selected"; ?>>Select Blood Group</option>
                    <option value="A (+ve)" <?php if ($blood_group == "A (+ve)")
                        echo "selected"; ?>>A (+ve)</option>
                    <option value="A (-ve)" <?php if ($blood_group == "A (-ve)")
                        echo "selected"; ?>>A (-ve)</option>
                    <option value="B (+ve)" <?php if ($blood_group == "B (+ve)")
                        echo "selected"; ?>>B (+ve)</option>
                    <option value="B (-ve)" <?php if ($blood_group == "B (-ve)")
                        echo "selected"; ?>>B (-ve)</option>
                    <option value="AB (+ve)" <?php if ($blood_group == "AB (+ve)")
                        echo "selected"; ?>>AB (+ve)</option>
                    <option value="AB (-ve)" <?php if ($blood_group == "AB (-ve)")
                        echo "selected"; ?>>AB (-ve)</option>
                    <option value="O(+ve)" <?php if ($blood_group == "O(+ve)")
                        echo "selected"; ?>>O(+ve)</option>
                    <option value="O(-ve)" <?php if ($blood_group == "O(-ve)")
                        echo "selected"; ?>>O(-ve)</option>
                </select>
           
            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" value="<?php echo $phone; ?>" class="form-control" required>
            </div>
            </div>
            <div class="form-group">
                <label>Location</label>
                
<input type="text" name="address" value="<?php echo $location; ?>" required>
            </div>
            <div class="form-group">
    <label for="last_donation_date">Last Donation Date:</label>
    <input type="date" class="form-control" name="last_donation" id="last_donation" value="<?php echo date('Y-m-d', strtotime($last_donation)); ?>">
</div>

            <button type="submit" name="submit">Update</button>
        </form>
    </div>
    </br>
    </br>
    <a href="index.php" class="btn btn-warning">Back</a>
</body>
</html>