// form validation
var form = document.getElementById('create-form');
var nameInput = document.getElementById('name');
var numberInput = document.getElementById('number');
var groupInput = document.getElementById('group');
var locationInput = document.getElementById('location');
var message = document.getElementById('message');

form.addEventListener('submit', function(event) {
    var errors = [];

    if (nameInput.value.trim() === '') {
        errors.push('Name is required.');
    }

    if (numberInput.value.trim() === '') {
        errors.push('Number is required.');
    } else if (!/^\d{11}$/.test(numberInput.value)) {
        errors.push('Number must be 11 digits.');
    }

    if (groupInput.value.trim() === '') {
        errors.push('Blood group is required.');
    }

    if (locationInput.value.trim() === '') {
        errors.push('Location is required.');
    }

    if (errors.length > 0) {
        event.preventDefault();
        message.innerHTML = '';
        for (var i = 0; i < errors.length; i++) {
            message.innerHTML += '<div class="error">' + errors[i] + '</div>';
        }
    }
});
