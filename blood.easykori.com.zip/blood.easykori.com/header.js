// Select the menu button and menu element
const menuButton = document.querySelector('.menu-toggle');
const menu = document.querySelector('.menu');

// Add click event listener to the menu button
menuButton.addEventListener('click', () => {
  // Toggle the "open" class on the menu
  menu.classList.toggle('open');
});
