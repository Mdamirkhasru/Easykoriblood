<?php require 'header.php'; ?>
<?php
if (isset($_POST['submit'])) {
    $to = "santoo.amirkhasru2002@gmail.com"; // Enter your address address here
    $name = $_POST['name'];
    $address = $_POST['address'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $headers = "From: " . $name . " <" . $address . ">\r\n" .
        "Reply-To: " . $address . "\r\n" .
        "X-Mailer: PHP/" . phpversion();
    if (mail($to, $subject, $message, $headers)) {
        echo '<div class="alert alert-success">Message sent successfully!</div>';
    } else {
        echo '<div class="alert alert-danger">Error sending message. Please try again later.</div>';
    }
}
?>
<div class="container">
    <h1>Contact Us</h1>
    <form action="submit_form.php" method="post">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="address">address:</label>
            <input type="address" class="form-control" id="address" name="address" required>
        </div>
        <div class="form-group">
            <label for="message">Message:</label>
            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>



<?php require 'footer.php'; ?>