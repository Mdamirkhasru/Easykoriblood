

    <div class="container">
		<h1>About Easykori Blood</h1>
		<hr>
		<p>Easykori Blood is a project of Easykori that focuses on creating an online database of blood donors in Bangladesh. The platform aims to connect blood donors with people who need blood transfusions quickly and easily. With Easykori Blood, users can search for blood donors based on blood group, location, and availability. The platform also provides information on blood donation and the benefits of becoming a blood donor. Easykori Blood aims to help save lives by making the process of finding blood donors faster and more efficient.</p>
		
		
	</div>

<?php
// include footer.php
require 'footer.php';
?>