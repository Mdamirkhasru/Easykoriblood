<?php
// start a new session if one is not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}?>
<?php
if (isset($_SESSION['role'])) {
  require 'header.php';
    include 'search.php';
  include 'allsearch.php';
   require 'register.php';

  include 'table.php';
  require 'footer.php';
}else{
  require 'header.php';
    require 'register.php';
   
//   include 'search.php';
//   include 'table.php';
  require 'footer.php';
}
?>
