<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 border rounded p-4">
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="form-group">
                    <label for="blood_type">Blood Group:</label>
                    <select class="form-control" name="blood_type" id="blood_type" required>
                        <option value="">Select Blood Group</option>
                        <option value="A (+ve)">A (+ve)</option>
                        <option value="A (-ve)">A (-ve)</option>
                        <option value="B (+ve)">B (+ve)</option>
                        <option value="B (-ve)">B (-ve)</option>
                        <option value="AB (+ve)">AB (+ve)</option>
                        <option value="AB (-ve)">AB (-ve)</option>
                        <option value="O (+ve)">O (+ve)</option>
                        <option value="O (-ve)">O (-ve)</option>
                    </select>
                    <label for="address" class="col-sm-2 col-form-label">District:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="address" id="address" require>
                    </div>
                </div>

                <div class="text-center"><button type="submit" class="btn btn-primary text-align-center">Search</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
        // Include database connection file
        include "db.php";

        // Check if form is submitted
        if (isset($_POST["blood_type"])) {
            // Get search keyword
            $search = $_POST["blood_type"];

            // Search donors in database
            $sql = "SELECT * FROM blood_donors WHERE blood_type='$search' && address='$address' ";
            $result = mysqli_query($conn, $sql);

            // Check if any donor found
            if (mysqli_num_rows($result) > 0) {

                echo "<th><h2>Search results for '$search'</h2></th>";
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
<div class="card border-success mb-3">
    <div class="card text-center">
        <div class="card-header">
            <?php echo $row["blood_type"]; ?>
        </div>
        <div class="card-body">
            <h5 class="card-title">
                <?php echo $row["full_name"]; ?>
            </h5>
            <p class="card-text">
                <?php echo $row["phone"]; ?> </br>
                <?php echo $row["address"]; ?></br>
                <?php echo $row["last_donation"]; ?>
                <?php echo $row["Organization"]; ?>
            </p>
            <a href="tel:0<?php echo $row["phone"]; ?>" class="btn btn-primary">Call Now</a>

        </div>
        <div class="card-footer text-muted">

        </div>
    </div>
</div>




<?php
                }
            } else {
                ?>
<div class="card border-warning mb-3 ">
    <div class="card text-center">
        <div class="card-header">Sorry</div>
        <div class="card-body text-warning">
            <h5 class="card-title">Didn't Match</h5>
            <p class="card-text">
                <?php
                                echo "No results found for $search "; ?>
            </p>
        </div>
    </div>
</div>






<?php
        }


   }

?>