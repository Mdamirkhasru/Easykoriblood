// get the table rows
var rows = document.getElementsByTagName('tr');

// create an array to store the row data
var rowData = [];
for (var i = 0; i < rows.length; i++) {
    rowData[i] = rows[i].getElementsByTagName('td');
}

// create a function to search the table
function searchTable() {
    var searchInput = document.getElementById('searchInput');
    var searchText = searchInput.value.toLowerCase();

    for (var i = 1; i < rows.length; i++) {
        var match = false;

        for (var j = 0; j < rowData[i-1].length; j++) {
            if (rowData[i-1][j].textContent.toLowerCase().indexOf(searchText) > -1) {
                match = true;
                break;
            }
        }

        if (match) {
            rows[i].style.display = '';
        } else {
            rows[i].style.display = 'none';
        }
    }
}

// add an event listener to the search button
var searchBtn = document.getElementById('searchBtn');
searchBtn.addEventListener('click', searchTable);
