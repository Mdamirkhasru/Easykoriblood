<?php
// start a new session if one is not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<div class="container">
  <div class="row">
    <div class="col-md-12 text-center">
      <a href="create.php" class="btn btn-primary"><?php if (isset($_SESSION['username'])) { ?>
        <h1>Add a New Donor</h1>
        <?php
        // code to add new donor goes here
        ?>
    <?php } else { ?>
        <h1>Register as a New Donor</h1>
        <?php
        // code to register new donor goes here
        ?>
    <?php } ?></a>
    </div>
  </div>
</div>
