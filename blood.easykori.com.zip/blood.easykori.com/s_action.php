<?php 
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'user' ){
?><?php 
include "header.php";
include "db.php";

// Check if form is submitted
if (isset($_POST["search"])) {
    // Get search keyword
    $search = $_POST["search"];

    // Search donors in database
    $sql = "SELECT * FROM blood_donors WHERE full_name LIKE '%$search%' OR blood_type LIKE '%$search%' OR address LIKE '%$search%' OR last_donation LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);

    // Check if any donor found
    if (mysqli_num_rows($result) > 0) {
        echo "<h2>Search results for '$search'</h2>";
        echo "<table>";
        echo "<tr><th>Name</th><th>Blood Group</th><th>Location</th><th>Last Donation</th><th>Action</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["full_name"] . "</td>";
            echo "<td>" . $row["blood_type"] . "</td>";
            echo "<td>" . $row["address"] . "</td>";
            echo "<td>" . $row["last_donation"] . "</td>";
           echo "<td><a href='edit.php?id=" . $row["id"] . "'>Edit</a> | <a href='tel:" . $row["phone"] . "'><button>Call</button></a></td>";


            echo "</tr>";
        }
        echo "</table>";
        ?>
       <br>
       <a href="index.php" class="btn"> <button type="submit" name="submit" class="btn btn-primary">Back</a> 
       <?php
    } else {
        echo "<h2>No results found for '$search'</h2>";
    }
}

?>

<?php include "footer.php";?>
<?php
   }
}else{
    echo "Sorry";
}
?>