<?php
// Connect to the database
$servername = "localhost";
$username = "easykori_123";
$password = "s@nto2002";
$dbname = "easykori_blood_donors";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the form data
$name = $_POST['name'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$bloodtype = $_POST['bloodtype'];
$lastdonationdate = $_POST['lastdonationdate'];

// Insert the data into the database
$sql = "INSERT INTO blood_donors (full_name, address, phone, blood_type, last_donation) VALUES ('$name', '$address', '$phone', '$bloodtype', '$lastdonationdate')";

/*INSERT INTO `blood_donors`(`id`, `full_name`, `address`, `phone`, `blood_type`, `last_donation`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6]) )*/

if ($conn->query($sql) === TRUE) {
   
    header("Location: index.php?success=1");
exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
