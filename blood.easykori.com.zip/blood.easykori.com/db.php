<?php
$servername = "localhost";
$username = "easykori_123";
$password = "s@nto2002";
$dbname = "easykori_blood_donors";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
