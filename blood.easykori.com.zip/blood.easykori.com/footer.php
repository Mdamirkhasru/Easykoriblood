<br>
<br>
<br>
<br>


<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
< link rel = "stylesheet"
href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
integrity = "sha512-AySKi1+/p4kr3OkkJ3lVgj43ZzX7sVAWY6k1iKU1TSeAlx7IydAcn6u56V7jK6zXu6+eU6otIuK7hTmTJQV7kw=="
crossorigin = "anonymous"
referrerpolicy = "no-referrer" / >
</script>
<footer class="footer bottom bg-light">



    <div class="container">
        <!-- <span class="text-muted">    <div class="container py-4"> -->
        <div class="row">
            <div class="col-md-6">
                <h2 class="mb-4">EasyKori</h2>
                <p class="mb-4">EasyKori is an organization that provides easy services everywhere. We aim to simplify
                    people's lives by offering a range of services that are convenient, reliable, and affordable.
                    Contact us at <a href="https://easykori.com"> easykori.com </a> to learn more about our services.
                    <a href="tel:+8801731513623">Call Now EasyKori</a>
                </p>
                <button type="button" class="btn btn-primary btn-lg mb-4"><a href="https://easykori.com"
                        style="color: #fff; text-decoration: none;">Visit Website</a></button>
            </div>
            <div class="col-md-3">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="https://blood.easykori.com/">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="login.php">login</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Connect with us</h5>
                <ul class="list-unstyled">
                    <li><a href="https://fb.me/amir2912"><i class="fab fa-facebook-f"></i>Facebook</a></li>
                    <li><a href="https://wa.me/+8801731513623"><i class="fab fa-whatsapp"></i>WhatsApp</a></li>
                    <li><a href="santo.amirkhasru2002@gmail.com"><i class="fab fa-gamil"></i> Gmail</a></li>
                    <li><a href="https://www.linkedin.com/in/amir2912/"><i class="fab fa-linkedin-in"></i> Linkedin</a>
                    </li>
                </ul>
            </div>

        </div>
    </div>
    <div class="bg-secondary py-2">
        <div class="container text-center">
            <p class="m-0">&copy; 2023 <a href="https://easykori.com"
                    style="color: black; text-decoration: none;">EasyKori</a>. All rights reserved.</p>
        </div>
    </div></span>
    </div>
</footer>


</body>

</html>