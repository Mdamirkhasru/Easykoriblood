<?php

session_start(); // Start the session
include "db.php"; // Include the database connection file

if (isset($_POST['name']) && isset($_POST['password'])) {
    // Get the name and password from the form
    $username = $_POST['name'];
    $password = $_POST['password'];

    // Sanitize the input to prevent SQL injection attacks
    $username = stripcslashes($username);
    $password = stripcslashes($password);
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    // Check if the username and password match any records in the database
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) { // If a match is found
        $row = mysqli_fetch_assoc($result);
        $role = $row["role"]; // Get the user's role from the matching record

        $_SESSION['role'] = $role; // Set the user's role in the session

        header('Location: index.php'); // Redirect the user to the index page
        exit();
    } else { // If no match is found
        // set error message
  $_SESSION['error'] = 'Invalid username or password. Please try again.';
        header('Location: login.php');
    }
}

?>