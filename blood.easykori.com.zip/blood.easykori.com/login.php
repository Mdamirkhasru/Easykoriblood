<?php
// start a new session if one is not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" type="image/x-icon" href="icon/myicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        .form-control {
            height: 50px;
            font-size: 18px;
        }

        .center-div {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .left-align {
            text-align: left;
        }

        .right-align {
            text-align: right;
        }

        .submit-btn {
            margin-top: auto;
            width: 100%;
        }
    </style>
</head>

<body>
<?php //require 'header.php'; ?>
    <div class="container">
        <div class="row center-div">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Sarstec Blood Donors Club Login Form</h3>
                    </div>
                    <div class="card-body">
                        <form action="role.php" method="POST">
                            <div class="form-group left-align">
                                <label for="name">Userame:</label>
                                <input type="name" class="form-control" id="name" placeholder="Enter name"
                                    name="name">
                            </div>
                            <div class="form-group right-align">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" id="password" placeholder="Enter password"
                                    name="password">
                            </div>
                            <button type="submit" class="btn btn-primary btn-block submit-btn">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php


// check if error message exists in session
if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger" role="alert">' . $_SESSION['error'] . '</div>';
    // unset error message to prevent it from showing again on page refresh
    unset($_SESSION['error']);
}
?>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.1/js/bootstrap.bundle.min.js"></script>
</body>

</html>