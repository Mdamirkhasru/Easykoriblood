<?php
// Start session if not already started
if (!isset($_SESSION)) {
    session_start();
}

// Check if user is logged in
if (isset($_SESSION['role'])) {
    // Include database connection file
    include "db.php";
    require "header.php";

    // Retrieve donor's information
    if (isset($_GET["id"])) {
        $id = $_GET["id"];

        $sql = "SELECT * FROM blood_donors WHERE id='$id'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $name = $row["full_name"];
            $phone = $row["phone"];
            $blood_group = $row["blood_type"];
            $location = $row["address"];
            $last_donation = $row["last_donation"];
            $Organization = $row["Organization"];

        } else {
            echo "No donor found";
            exit();
        }
    } else {
        echo "Invalid request";
        exit();
    }
?>

<!-- HTML code for view donor information -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Donor Information</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <br>
    <br>
    <br>
    <br>
    <div class="container">
        <div class="col-md-12 text-center">
            <h2>Donor Information</h2>
            <table>
                <tr>
                    <th>Name</th>
                    <td><?php echo $name; ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo $phone; ?></td>
                </tr>
                <tr>
                    <th>Blood Group</th>
                    <td><?php echo $blood_group; ?></td>
                </tr>
                <tr>
                    <th>Location</th>
                    <td><?php echo $location; ?></td>
                </tr>
                <tr>
                    <th>Last Donation</th>
                    <td><?php echo $last_donation; ?></td>
                </tr>
            </table>
            <a href="index.php" class="btn">Back</a>
        </div>
    </div>
</body>
</html>

<?php
    // Redirect user to login page if not logged in
} else {
    header('Location: login.php');
}
?>
