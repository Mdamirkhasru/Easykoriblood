<?php
// start a new session if one is not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<?php
if (isset($_SESSION['role'])) {
  require 'header.php';
  
  
  
?>
<?php
// establish database connection
$servername = "localhost";
$username = "easykori_123";
$password = "s@nto2002";
$dbname = "easykori_blood_donors";
$conn = new mysqli($servername, $username, $password, $dbname);

// check for database connection errors
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// perform an SQL query to retrieve donor information
$sql = "SELECT * FROM  blood_donors ";
$result = $conn->query($sql);

// output the results in an HTML table
if ($result->num_rows > 0) {
?>
<div class="table-responsive" style="min-width: 300px;">
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">Full Name</th>
        <th scope="col">Address</th>
        <th scope="col">Phone</th>
        <th scope="col">Blood Type</th>
        <th scope="col">Last Donation</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
<?php
  // output data of each row
  while($row = $result->fetch_assoc()) {
?>
      <tr>
        <td><?php echo $row["full_name"]; ?></td>
        <td><?php echo $row["address"]; ?></td>
        <td><?php echo $row["phone"]; ?></td>
        <td><?php echo $row["blood_type"]; ?></td>
        <td><?php echo $row["last_donation"]; ?></td>
        <td>
          <a href='edit.php?id=<?php echo $row["id"]; ?>' class='btn btn-primary'>Edit</a>
          <a href='tel:0<?php echo $row["phone"]; ?>' class='btn btn-secondary'>Call</a>
        </td>
      </tr>
<?php
  }
?>
    </tbody>
  </table>
</div>
<?php
} else {
  echo "0 results";
}

// close database connection
$conn->close();


}else{
   header('Location: index.php');
exit;
}
?>
