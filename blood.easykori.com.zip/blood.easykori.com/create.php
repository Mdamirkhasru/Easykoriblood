<?php
// start a new session if one is not already started

?>

<?php require 'header.php'; ?>
<?php require 'search.php'; ?>

<div class="container">
    <h1>Add Donor</h1>
    <?php
    // check if the form has been submitted
    if (isset($_POST['submit'])) {
        // retrieve form data
        $name = $_POST['full_name'];
        $phone = $_POST['phone'];
        $blood_group = $_POST['blood_type'];
        $location = $_POST['address']; 
        $Organization = $_POST['Organization'];
        
        $last_donation = !empty($_POST['last_donation']) ? $_POST['last_donation'] : null;

        // connect to the database
        require 'db.php';

        // check connection
        if (!$conn) {
            die('Database connection failed.');
        }

        // insert donor data into the database
        $sql = "INSERT INTO blood_donors (full_name, phone, blood_type, Organization, address, last_donation) VALUES ('$name', '$phone', '$blood_group', '$Organization', '$location', " . ($last_donation_date ? "'$last_donation_date'" : "NULL") . ")";
        $result = mysqli_query($conn, $sql);

        // check if the query was successful
        if ($result) {
            echo '<div class="alert alert-success" role="alert">Donor added successfully.</div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">Error adding donor: '.mysqli_error($conn).'</div>';
        }

        // close database connection
        mysqli_close($conn);
    }
    ?>
        
            
                <form method="post"><div class="container">
    <div class="form-group row">
        <label for="full_name" class="col-sm-2 col-form-label">Name:</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="full_name" id="full_name" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="phone" class="col-sm-2 col-form-label">Phone:</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="phone" id="phone" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="blood_type" class="col-sm-2 col-form-label">Blood Group:</label>
        <div class="col-sm-10">
            <select class="form-control" name="blood_type" id="blood_type" required>
                <option value="">Select Blood Group</option>
                <option value="A (+ve)">A (+ve)</option>
                <option value="A (-ve)">A (-ve)</option>
                <option value="B (+ve)">B (+ve)</option>
                <option value="B (-ve)">B (-ve)</option>
                <option value="AB (+ve)">AB (+ve)</option>
                <option value="AB (-ve)">AB (-ve)</option>
                <option value="O (+ve)">O (+ve)</option>
                <option value="O (-ve)">O (-ve)</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="address" class="col-sm-2 col-form-label">Location:</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="address" id="address" required>
        </div>
    </div><div class="form-group row">
        <label for="Organization" class="col-sm-2 col-form-label">Organization:</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="address" id="address" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="last_donation_date" class="col-sm-2 col-form-label">Last Donation Date:</label>
        <div class="col-sm-10">
            <input type="date" class="form-control" name="last_donation" id="last_donation">
        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-10 offset-sm-2">
            <button type="submit" name="submit" class="btn btn-primary">Add</button>
        </div>
    </div>
</form>

            <a href="index.php" class="btn"> <button type="submit" name="submit" class="btn btn-primary">Back</a>
        </div>
    </div>
    <?php require 'footer.php'; ?>