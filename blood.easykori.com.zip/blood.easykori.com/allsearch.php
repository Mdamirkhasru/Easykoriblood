    <?php 
    if (isset($_SESSION['role'])) {
        if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'user' ){
    ?>

    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 border rounded p-4">
        <form method="POST" class="form-inline my-2 my-lg-0" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <label for="search">Enter your keyword : &nbsp;&nbsp;&nbsp;</label>
        <input class="form-control mr-sm-2" type="search" name="search" placeholder="Search" aria-label="Search">
    <div class="text-center"><button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button></div>
    </form>
        </div>
    </div>
    </div>

    <!--<body>-->
    
    <!--    <h1>Search for blood donors:</h1>-->
    <!--    <form method="POST" action="">-->
    <!--        <input type="text" name="search" placeholder="Enter keyword">-->
    <!--        <input type="submit" value="Search">-->
    <!--    </form>-->

    <?php
    // Include database connection file
    include "db.php";

    // Check if form is submitted
    if (isset($_POST["search"])) {
        // Get search keyword
        $search = $_POST["search"];

        // Search donors in database
        $sql = "SELECT * FROM blood_donors WHERE full_name LIKE '%$search%' OR blood_type LIKE '%$search%' OR address LIKE '%$search%' OR last_donation LIKE '%$search%'";
        $result = mysqli_query($conn, $sql);

        // Check if any donor found
        if (mysqli_num_rows($result) > 0) {
           
            echo "<th><h2>Search results for '$search'</h2></th>";
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
               <div class="card border-success mb-3">
                <div class="card text-center">
  <div class="card-header"><?php echo  $row["blood_type"]; ?></div>
  <div class="card-body">
    <h5 class="card-title"><?php echo $row["full_name"]; ?></h5>
    <p class="card-text"><?php echo $row["phone"]; ?> </br><?php echo $row["address"]; ?></br><?php echo $row["last_donation"]; ?> </p>
    <a href="tel:0<?php echo $row["phone"]; ?>" class="btn btn-primary">Call Now</a>
    <a href="edit.php?id=<?php echo $row["id"]; ?>" class="btn btn-light">Update</a>
    
    </div>
    <div class="card-footer text-muted">
   
  </div>
</div>   
</div>
                            
                      
                
                
          <?php 
            }
        }else {
            ?>
            <div class="card border-warning mb-3 ">
                <div class="card text-center">
  <div class="card-header">Sorry</div>
  <div class="card-body text-warning">
    <h5 class="card-title">Didn't Match</h5>
    <p class="card-text"><?php
            echo "No results found for $search ";?></p>
  </div>
</div>
</div>
            
            <?php
            
        }  
          ?>
       
       
        

<?php 
    }
}
    }
?> 
